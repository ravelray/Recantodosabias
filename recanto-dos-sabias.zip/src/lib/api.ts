import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { ZodError } from "zod";
import { getSession, can, type Session } from "./auth";
import { sql } from "./db";

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}

export const clientIp = () => headers().get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;

export async function audit(userId: string | null, action: string, entity: string, entityId: string | null, before: any = null, after: any = null) {
  await sql`insert into audit_logs(user_id, action, entity, entity_id, before_data, after_data, ip)
            values (${userId}, ${action}, ${entity}, ${entityId},
                    ${before ? JSON.stringify(before) : null}::jsonb, ${after ? JSON.stringify(after) : null}::jsonb, ${clientIp()})`;
}

type Ctx = { s: Session; req: Request; params: any };

// Toda API passa por aqui: exige sessão válida e permissão (checadas no servidor, não só no visual).
export function api(perm: string | string[] | null, fn: (c: Ctx) => Promise<any>) {
  return async (req: Request, ctx: { params: any }) => {
    try {
      const s = await getSession();
      if (!s) throw new HttpError(401, "Não autenticado");
      if (perm) {
        const list = Array.isArray(perm) ? perm : [perm];
        let ok = false;
        for (const p of list) if (await can(s.role, p)) { ok = true; break; }
        if (!ok) throw new HttpError(403, "Sem permissão para esta ação");
      }
      const out = await fn({ s, req, params: ctx?.params });
      return NextResponse.json(out ?? { ok: true });
    } catch (e: any) {
      if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
      if (e instanceof ZodError) {
        return NextResponse.json({ error: "Dados inválidos: " + e.issues.map((i) => i.path.join(".") + " " + i.message).join("; ") }, { status: 400 });
      }
      if (e?.code === "23514") return NextResponse.json({ error: e.message }, { status: 400 });
      if (e?.code === "23505") return NextResponse.json({ error: "Registro duplicado" }, { status: 409 });
      console.error(e);
      return NextResponse.json({ error: "Erro interno" }, { status: 500 });
    }
  };
}

export const body = async (req: Request) => req.json().catch(() => { throw new HttpError(400, "Corpo da requisição inválido"); });
