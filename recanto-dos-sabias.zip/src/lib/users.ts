import { HttpError } from "./api";
import { can, type Session } from "./auth";

// Regras: só DESENVOLVEDOR mexe em contas de DESENVOLVEDOR; contas da PORTARIA exigem users.manage_portaria; as demais exigem users.manage_all.
export async function assertCanManage(s: Session, targetRole: string) {
  if (targetRole === "DESENVOLVEDOR" && s.role !== "DESENVOLVEDOR") throw new HttpError(403, "Apenas o Desenvolvedor gerencia contas de Desenvolvedor");
  const ok = targetRole === "PORTARIA"
    ? (await can(s.role, "users.manage_portaria")) || (await can(s.role, "users.manage_all"))
    : await can(s.role, "users.manage_all");
  if (!ok) throw new HttpError(403, "Sem permissão para gerenciar esta conta");
}

