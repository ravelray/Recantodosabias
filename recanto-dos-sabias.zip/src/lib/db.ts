import { neon } from "@neondatabase/serverless";

// Todas as consultas usam parâmetros (template tag ou sql.query com $1, $2...), nunca concatenação: protege contra SQL Injection.
export const sql = neon(process.env.DATABASE_URL as string);
