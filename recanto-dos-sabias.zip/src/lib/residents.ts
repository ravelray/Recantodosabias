import { z } from "zod";
import { sql } from "./db";
import { encrypt } from "./crypto";
import { HttpError } from "./api";

export const phoneSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  ownerName: z.string().trim().min(1).max(100),
  ddd: z.string().regex(/^\d{2}$/, "DDD inválido"),
  number: z.string().regex(/^\d{8,9}$/, "número inválido"),
  kind: z.enum(["CELULAR", "TELEFONE"]),
  label: z.enum(["PRINCIPAL", "CONJUGE", "FAMILIAR", "OUTRO"]),
  isPriority: z.boolean(),
  sharedWithUnit: z.boolean(),
  active: z.boolean(),
});
export const residentSchema = z.object({
  fullName: z.string().trim().min(3).max(150),
  cpf: z.string().max(20).optional().nullable(),
  block: z.string().trim().min(1).max(30),
  apt: z.string().trim().min(1).max(20),
  email: z.string().trim().email().optional().or(z.literal("")).nullable(),
  bond: z.enum(["PROPRIETARIO", "INQUILINO", "FAMILIAR"]),
  active: z.boolean(),
  adminNote: z.string().max(1000).optional().nullable(),
  phones: z.array(phoneSchema).max(4, "Máximo de 4 telefones por morador"),
});
export type ResidentInput = z.infer<typeof residentSchema>;

export async function findOrCreateUnit(block: string, apt: string): Promise<number> {
  await sql`insert into blocks(name) values (${block}) on conflict (lower(name)) where deleted_at is null do nothing`;
  const b = await sql`select id from blocks where lower(name) = lower(${block}) and deleted_at is null`;
  await sql`insert into units(block_id, number) values (${b[0].id}, ${apt})
            on conflict (block_id, lower(number)) where deleted_at is null do nothing`;
  const u = await sql`select id from units where block_id = ${b[0].id} and lower(number) = lower(${apt}) and deleted_at is null`;
  return u[0].id;
}

export async function saveResident(userId: string, id: string | null, d: ResidentInput) {
  const unitId = await findOrCreateUnit(d.block, d.apt);
  const cpfDigits = d.cpf ? d.cpf.replace(/\D/g, "") : "";
  if (cpfDigits && cpfDigits.length !== 11) throw new HttpError(400, "CPF deve ter 11 dígitos");
  let rid = id;
  if (!id) {
    const r = await sql`insert into residents(unit_id, full_name, cpf_encrypted, email, bond, active, admin_note, created_by)
      values (${unitId}, ${d.fullName}, ${cpfDigits ? encrypt(cpfDigits) : null}, ${d.email || null}, ${d.bond}::bond_kind, ${d.active}, ${d.adminNote || null}, ${userId})
      returning id`;
    rid = r[0].id;
  } else {
    const cpfProvided = d.cpf !== undefined;
    const r = await sql`update residents set unit_id = ${unitId}, full_name = ${d.fullName},
        cpf_encrypted = case when ${cpfProvided}::boolean then ${cpfDigits ? encrypt(cpfDigits) : null} else cpf_encrypted end,
        email = ${d.email || null}, bond = ${d.bond}::bond_kind, active = ${d.active}, admin_note = ${d.adminNote || null}, updated_at = now()
      where id = ${id} and deleted_at is null returning id`;
    if (!r[0]) throw new HttpError(404, "Morador não encontrado");
  }
  // Telefones: o que não veio na lista é desativado (exclusão lógica); o resto é atualizado ou criado.
  const keep = d.phones.filter((p) => p.id).map((p) => p.id as string);
  await sql`update phones set deleted_at = now() where resident_id = ${rid} and deleted_at is null and not (id = any(${keep}::uuid[]))`;
  for (const p of d.phones) {
    if (p.id) {
      const r = await sql`update phones set owner_name = ${p.ownerName}, ddd = ${p.ddd}, number = ${p.number}, kind = ${p.kind}::phone_kind,
          label = ${p.label}::phone_label, is_priority = ${p.isPriority}, shared_with_unit = ${p.sharedWithUnit}, active = ${p.active}, updated_at = now()
        where id = ${p.id} and resident_id = ${rid} and deleted_at is null returning id`;
      if (!r[0]) throw new HttpError(400, "Telefone não pertence a este morador");
    } else {
      await sql`insert into phones(resident_id, owner_name, ddd, number, kind, label, is_priority, shared_with_unit, active)
        values (${rid}, ${p.ownerName}, ${p.ddd}, ${p.number}, ${p.kind}::phone_kind, ${p.label}::phone_label, ${p.isPriority}, ${p.sharedWithUnit}, ${p.active})`;
    }
  }
  return rid as string;
}
