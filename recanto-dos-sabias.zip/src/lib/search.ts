import { sql } from "./db";

const esc = (s: string) => s.replace(/[\\%_]/g, (m) => "\\" + m);

// Cada palavra digitada precisa casar com nome, bloco, apartamento ou telefone (4+ dígitos).
export async function searchResidents(opts: { q?: string; block?: string; apt?: string; includeInactive?: boolean; limit?: number }) {
  const params: any[] = [];
  const conds: string[] = ["r.deleted_at is null"];
  if (!opts.includeInactive) conds.push("r.active");
  const tokens = (opts.q || "").trim().split(/\s+/).filter(Boolean).slice(0, 5);
  for (const t of tokens) {
    params.push(esc(t.toLowerCase()));
    const i = params.length;
    let c = `(lower(r.full_name) like '%' || $${i} || '%' or lower(b.name) = $${i} or lower(u.number) = $${i}`;
    const digits = t.replace(/\D/g, "");
    if (digits.length >= 4) {
      params.push(digits);
      c += ` or exists (select 1 from phones p where p.resident_id = r.id and p.deleted_at is null and (p.ddd || p.number) like '%' || $${params.length} || '%')`;
    }
    conds.push(c + ")");
  }
  if (opts.block) { params.push(opts.block.toLowerCase()); conds.push(`lower(b.name) = $${params.length}`); }
  if (opts.apt) { params.push(opts.apt.toLowerCase()); conds.push(`lower(u.number) = $${params.length}`); }
  const limit = Math.min(opts.limit ?? 30, 100);
  const text = `select r.id, r.full_name, r.bond, r.active, b.name as block, u.number as apt, u.id as unit_id
    from residents r join units u on u.id = r.unit_id join blocks b on b.id = u.block_id
    where ${conds.join(" and ")} order by b.name, u.number, r.full_name limit ${limit}`;
  return (await sql.query(text, params)) as any[];
}
