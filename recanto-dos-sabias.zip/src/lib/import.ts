import { sql } from "./db";
import { parsePhone } from "./phones";

export type ImportRow = {
  line: number; name: string; block: string; apt: string; bond: string; email: string;
  phones: { ddd: string; number: string }[]; status: "OK" | "ERRO" | "DUPLICADO"; messages: string[];
};

const BONDS: Record<string, string> = { proprietario: "PROPRIETARIO", proprietário: "PROPRIETARIO", inquilino: "INQUILINO", familiar: "FAMILIAR" };
const norm = (s: any) => String(s ?? "").trim();

// Colunas esperadas: nome, bloco, apartamento, vinculo, email, telefone1..telefone4
export async function validateRows(input: any[]) {
  const existing = await sql`select lower(r.full_name) as n, lower(b.name) as b, lower(u.number) as a from residents r
    join units u on u.id = r.unit_id join blocks b on b.id = u.block_id where r.deleted_at is null`;
  const seen = new Set(existing.map((e) => `${e.n}|${e.b}|${e.a}`));
  const rows: ImportRow[] = input.map((raw, idx) => {
    const messages: string[] = [];
    const name = norm(raw.nome ?? raw.name), block = norm(raw.bloco ?? raw.block), apt = norm(raw.apartamento ?? raw.apto ?? raw.apt);
    const email = norm(raw.email);
    const bondRaw = norm(raw.vinculo ?? raw.vínculo ?? raw.bond).toLowerCase();
    const bond = BONDS[bondRaw] || "PROPRIETARIO";
    if (bondRaw && !BONDS[bondRaw]) messages.push("Vínculo não reconhecido, usado 'Proprietário'");
    if (name.length < 3) messages.push("Nome ausente ou muito curto");
    if (!block) messages.push("Bloco ausente");
    if (!apt) messages.push("Apartamento ausente");
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) messages.push("E-mail inválido");
    const phones: { ddd: string; number: string }[] = [];
    for (let i = 1; i <= 4; i++) {
      const v = norm(raw[`telefone${i}`]);
      if (!v) continue;
      const p = parsePhone(v);
      if (!p) messages.push(`Telefone ${i} inválido (${v})`); else if (!phones.some((x) => x.ddd === p.ddd && x.number === p.number)) phones.push(p);
    }
    let status: ImportRow["status"] = messages.some((m) => !m.startsWith("Vínculo")) ? "ERRO" : "OK";
    if (status === "OK") {
      const key = `${name.toLowerCase()}|${block.toLowerCase()}|${apt.toLowerCase()}`;
      if (seen.has(key)) { status = "DUPLICADO"; messages.push("Já cadastrado (ou repetido na planilha)"); } else seen.add(key);
    }
    return { line: idx + 2, name, block, apt, bond, email, phones, status, messages };
  });
  return { rows, summary: { total: rows.length, ok: rows.filter((r) => r.status === "OK").length, errors: rows.filter((r) => r.status === "ERRO").length, duplicates: rows.filter((r) => r.status === "DUPLICADO").length } };
}
