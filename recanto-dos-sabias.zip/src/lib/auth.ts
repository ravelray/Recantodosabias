import { cookies } from "next/headers";
import crypto from "crypto";
import { sql } from "./db";

export const COOKIE = "rds_session";
export type Role = "DESENVOLVEDOR" | "ADMINISTRACAO" | "PORTARIA";
export type Session = { userId: string; username: string; fullName: string; role: Role };

export const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

export async function createSession(userId: string, ip: string | null, ua: string | null) {
  const token = crypto.randomBytes(32).toString("hex");
  await sql`insert into sessions(user_id, token_hash, ip, user_agent, expires_at)
            values (${userId}, ${sha(token)}, ${ip}, ${ua}, now() + interval '12 hours')`;
  cookies().set(COOKIE, token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 12,
  });
}

export async function getSession(): Promise<Session | null> {
  const t = cookies().get(COOKIE)?.value;
  if (!t) return null;
  const r = await sql`
    select u.id, u.username, u.full_name, u.role
    from sessions s join users u on u.id = s.user_id
    where s.token_hash = ${sha(t)} and s.revoked_at is null and s.expires_at > now()
      and u.active and u.deleted_at is null`;
  if (!r[0]) return null;
  return { userId: r[0].id, username: r[0].username, fullName: r[0].full_name, role: r[0].role };
}

export async function destroySession() {
  const t = cookies().get(COOKIE)?.value;
  if (t) await sql`update sessions set revoked_at = now() where token_hash = ${sha(t)}`;
  cookies().delete(COOKIE);
}

// DESENVOLVEDOR sempre tem tudo (não dá para se trancar para fora). Os demais seguem a tabela role_permissions.
export async function can(role: Role, code: string) {
  if (role === "DESENVOLVEDOR") return true;
  const r = await sql`select allowed from role_permissions where role = ${role}::role_kind and permission_code = ${code}`;
  return r[0]?.allowed === true;
}

export async function allowedPerms(role: Role): Promise<string[]> {
  if (role === "DESENVOLVEDOR") return (await sql`select code from permissions`).map((x) => x.code);
  return (await sql`select permission_code as code from role_permissions where role = ${role}::role_kind and allowed`).map((x) => x.code);
}
