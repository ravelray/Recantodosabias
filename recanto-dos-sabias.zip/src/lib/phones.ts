// Normaliza telefone brasileiro: devolve {ddd, number} ou null se inválido.
export function parsePhone(raw: string): { ddd: string; number: string } | null {
  let d = (raw || "").replace(/\D/g, "");
  if ((d.length === 12 || d.length === 13) && d.startsWith("55")) d = d.slice(2);
  if (d.length !== 10 && d.length !== 11) return null;
  const ddd = d.slice(0, 2), number = d.slice(2);
  if (ddd[0] === "0" || ddd === "00") return null;
  if (number.length === 9 && number[0] !== "9") return null;
  return { ddd, number };
}
