export async function j(url: string, opts?: { method?: string; body?: any }) {
  const r = await fetch(url, {
    method: opts?.method ?? "GET",
    headers: { "Content-Type": "application/json" },
    body: opts?.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && typeof window !== "undefined") window.location.href = "/login";
  if (!r.ok) throw new Error(d.error || "Erro inesperado");
  return d;
}
export const fmtPhone = (ddd: string, n: string) => `(${ddd}) ${n.length === 9 ? n.slice(0, 5) + "-" + n.slice(5) : n.slice(0, 4) + "-" + n.slice(4)}`;
export const fmtDate = (s: string) => new Date(s).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
export const BOND: Record<string, string> = { PROPRIETARIO: "Proprietário", INQUILINO: "Inquilino", FAMILIAR: "Familiar" };
export const LABEL: Record<string, string> = { PRINCIPAL: "Principal", CONJUGE: "Cônjuge", FAMILIAR: "Familiar", OUTRO: "Outro" };
export const OBS_CATEGORIES = ["Contato solicitado", "Não atender no horário", "Telefone atualizado", "Aguardando retorno", "Contato alternativo", "Outro"];
export const OCC_CATEGORIES = ["Barulho", "Segurança", "Manutenção", "Limpeza", "Acesso", "Outro"];
