import { NextResponse, type NextRequest } from "next/server";

const PUBLIC = ["/login", "/reset", "/api/auth/login", "/api/auth/reset"];

// Barreira rápida: sem cookie, nada abre. A validação real da sessão e das
// permissões é feita no servidor em cada página e em cada API.
export function middleware(req: NextRequest) {
  const p = req.nextUrl.pathname;
  if (PUBLIC.includes(p)) return NextResponse.next();
  if (!req.cookies.get("rds_session")) {
    if (p.startsWith("/api/")) return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
    return NextResponse.redirect(new URL("/login", req.url));
  }
  return NextResponse.next();
}
export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
