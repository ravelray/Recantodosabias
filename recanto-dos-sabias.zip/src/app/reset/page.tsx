"use client";
import { useEffect, useState } from "react";

export default function Reset() {
  const [token, setToken] = useState(""), [p1, setP1] = useState(""), [p2, setP2] = useState(""), [msg, setMsg] = useState(""), [done, setDone] = useState(false);
  useEffect(() => { setToken(new URLSearchParams(window.location.search).get("token") || ""); }, []);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setMsg("");
    if (p1 !== p2) return setMsg("As senhas não conferem");
    const r = await fetch("/api/auth/reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password: p1 }) });
    const d = await r.json().catch(() => ({}));
    if (r.ok) setDone(true); else setMsg(d.error || "Erro");
  }
  return (
    <div className="login"><div className="box"><h1>Nova senha</h1>
      {done ? <><div className="ok">Senha alterada com sucesso.</div><a className="btn green" href="/login">Ir para o login</a></> : (
        <form onSubmit={go}>
          <label>Nova senha (mínimo 10 caracteres)</label><input type="password" value={p1} onChange={(e) => setP1(e.target.value)} required minLength={10} />
          <label>Repita a senha</label><input type="password" value={p2} onChange={(e) => setP2(e.target.value)} required minLength={10} />
          {msg && <div className="err">{msg}</div>}
          <button className="btn green" style={{ width: "100%", marginTop: 14 }}>Salvar senha</button>
        </form>)}
    </div></div>
  );
}
