import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Recanto dos Sabiás", description: "Sistema da portaria do Condomínio Recanto dos Sabiás", robots: { index: false, follow: false } };

export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="pt-BR"><body>{children}</body></html>);
}
