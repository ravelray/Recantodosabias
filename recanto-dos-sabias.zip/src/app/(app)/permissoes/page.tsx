"use client";
import { useEffect, useState } from "react";
import { j } from "@/lib/client";

export default function Permissoes() {
  const [d, setD] = useState<any>(null), [err, setErr] = useState("");
  async function load() { try { setD(await j("/api/permissions")); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { load(); }, []);
  async function toggle(role: string, code: string, allowed: boolean) { setErr(""); try { await j("/api/permissions", { method: "PUT", body: { role, code, allowed } }); load(); } catch (e: any) { setErr(e.message); } }
  if (!d) return <div>{err ? <div className="err">{err}</div> : "Carregando..."}</div>;
  const isDev = d.myRole === "DESENVOLVEDOR";
  let last = "";
  return (
    <div><h1>Permissões por perfil</h1>
      <p className="mut">Defina o que a Portaria pode fazer. O Desenvolvedor sempre tem acesso total. Apenas o Desenvolvedor altera as permissões da Administração.</p>
      {err && <div className="err">{err}</div>}
      <div className="card tablewrap"><table><thead><tr><th>Função</th><th>Administração</th><th>Portaria</th></tr></thead><tbody>
        {d.permissions.map((p: any) => { const head = p.grp !== last; last = p.grp; return (<>
          {head && <tr key={"g" + p.grp}><td colSpan={3}><b>{p.grp}</b></td></tr>}
          <tr key={p.code}><td>{p.description}</td>
            <td><input type="checkbox" style={{ width: 22, height: 22 }} disabled={!isDev} checked={!!d.matrix.ADMINISTRACAO[p.code]} onChange={(e) => toggle("ADMINISTRACAO", p.code, e.target.checked)} /></td>
            <td><input type="checkbox" style={{ width: 22, height: 22 }} checked={!!d.matrix.PORTARIA[p.code]} onChange={(e) => toggle("PORTARIA", p.code, e.target.checked)} /></td></tr></>); })}
      </tbody></table></div>
    </div>
  );
}
