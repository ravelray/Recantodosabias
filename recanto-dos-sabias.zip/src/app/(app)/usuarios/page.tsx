"use client";
import { useEffect, useState } from "react";
import { j, fmtDate } from "@/lib/client";
import { useMe } from "@/components/Shell";

const ROLE: Record<string, string> = { DESENVOLVEDOR: "Desenvolvedor", ADMINISTRACAO: "Administração", PORTARIA: "Portaria" };

export default function Usuarios() {
  const me = useMe();
  const [users, setUsers] = useState<any[]>([]), [myId, setMyId] = useState(""), [err, setErr] = useState(""), [msg, setMsg] = useState(""), [link, setLink] = useState("");
  const [f, setF] = useState({ username: "", fullName: "", email: "", password: "", role: "PORTARIA" });
  const [show, setShow] = useState(false);
  const roles = me.perms.includes("users.manage_all") ? ["PORTARIA", "ADMINISTRACAO", ...(me.role === "DESENVOLVEDOR" ? ["DESENVOLVEDOR"] : [])] : ["PORTARIA"];

  async function load() { try { const d = await j("/api/users"); setUsers(d.users); setMyId(d.me); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { load(); }, []);
  async function add() { setErr(""); try { await j("/api/users", { method: "POST", body: f }); setShow(false); setF({ username: "", fullName: "", email: "", password: "", role: "PORTARIA" }); setMsg("Conta criada."); load(); } catch (e: any) { setErr(e.message); } }
  async function act(id: string, body: any) { setErr(""); try { await j(`/api/users/${id}`, { method: "PUT", body }); load(); } catch (e: any) { setErr(e.message); } }
  async function reset(id: string) { setErr(""); try { setLink((await j(`/api/users/${id}/reset`, { method: "POST" })).link); } catch (e: any) { setErr(e.message); } }
  async function del(id: string) { if (!confirm("Excluir esta conta?")) return; try { await j(`/api/users/${id}`, { method: "DELETE" }); load(); } catch (e: any) { setErr(e.message); } }

  return (
    <div><h1>Funcionários e contas</h1>
      <button className="btn green" onClick={() => setShow(!show)}>+ Nova conta</button>
      {msg && <div className="ok">{msg}</div>}{err && <div className="err">{err}</div>}
      {link && <div className="card"><b>Link de redefinição (vale 2 horas, uso único):</b><div style={{ wordBreak: "break-all", margin: "6px 0" }}>{link}</div>
        <button className="btn ghost sm" onClick={() => navigator.clipboard.writeText(link)}>Copiar link</button> <button className="btn ghost sm" onClick={() => setLink("")}>Fechar</button></div>}
      {show && <div className="card" style={{ marginTop: 10 }}>
        <div className="row"><div><label>Usuário</label><input value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} autoCapitalize="none" /></div><div><label>Nome completo</label><input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></div></div>
        <div className="row"><div><label>E-mail (opcional)</label><input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div><div><label>Senha inicial (mín. 10)</label><input type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div></div>
        <label>Perfil</label><select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>{roles.map((r) => <option key={r} value={r}>{ROLE[r]}</option>)}</select>
        <button className="btn green" style={{ marginTop: 10 }} onClick={add}>Criar conta</button></div>}
      <div className="card tablewrap" style={{ marginTop: 12 }}><table><thead><tr><th>Nome</th><th>Usuário</th><th>Perfil</th><th>Último acesso</th><th>Situação</th><th></th></tr></thead><tbody>
        {users.map((u) => <tr key={u.id}><td>{u.fullName}</td><td>{u.username}</td><td>{ROLE[u.role]}</td><td>{u.lastLoginAt ? fmtDate(u.lastLoginAt) : "—"}</td>
          <td><span className={"badge " + (u.active ? "" : "red")}>{u.active ? "Ativa" : "Bloqueada"}</span></td>
          <td style={{ whiteSpace: "nowrap" }}>{u.id !== myId && <>
            <button className="btn ghost sm" onClick={() => act(u.id, { active: !u.active })}>{u.active ? "Bloquear" : "Reativar"}</button>{" "}
            <button className="btn ghost sm" onClick={() => reset(u.id)}>Link de senha</button>{" "}
            <button className="btn red sm" onClick={() => del(u.id)}>Excluir</button></>}</td></tr>)}
      </tbody></table></div>
    </div>
  );
}
