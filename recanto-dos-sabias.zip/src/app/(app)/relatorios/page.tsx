"use client";
import { useEffect, useState } from "react";
import { j, fmtDate, OBS_CATEGORIES, OCC_CATEGORIES } from "@/lib/client";

const TYPES: [string, string][] = [["atendimentos", "Atendimentos realizados"], ["consultas", "Consultas de moradores"], ["observacoes", "Observações"], ["ocorrencias", "Ocorrências"], ["alteracoes", "Alterações de cadastro"], ["acessos", "Acessos dos funcionários"]];

function Bars({ data }: { data: { label: string; total: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.total));
  return <div className="bars" style={{ marginBottom: 24 }}>{data.map((d) => <div key={d.label} title={`${d.label}: ${d.total}`} style={{ height: `${(d.total / max) * 100}%` }}><span>{d.label}</span></div>)}</div>;
}

export default function Relatorios() {
  const [sum, setSum] = useState<any>(null), [type, setType] = useState("atendimentos"), [from, setFrom] = useState(""), [to, setTo] = useState(""), [user, setUser] = useState(""), [cat, setCat] = useState("");
  const [rep, setRep] = useState<any>(null), [err, setErr] = useState("");
  useEffect(() => { j("/api/reports?type=resumo").then(setSum).catch((e) => setErr(e.message)); }, []);
  async function run() { setErr(""); try { setRep(await j(`/api/reports?type=${type}&from=${from}&to=${to}&userId=${user}&category=${encodeURIComponent(cat)}`)); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { run(); }, [type]);
  const cats = type === "observacoes" ? OBS_CATEGORIES : type === "ocorrencias" ? OCC_CATEGORIES : [];
  return (
    <div><h1>Relatórios</h1>{err && <div className="err">{err}</div>}
      {sum && <div className="grid2" style={{ marginBottom: 12 }}>
        {[["Moradores ativos", sum.summary.residents], ["Atendimentos (30 dias)", sum.summary.atendimentos], ["Consultas (30 dias)", sum.summary.consultas], ["Ocorrências em aberto", sum.summary.occ_open]].map(([l, v]) => <div key={l as string} className="card"><div className="mut">{l}</div><div className="stat">{v as number}</div></div>)}
        <div className="card" style={{ gridColumn: "1/-1" }}><div className="mut">Atendimentos por dia (últimos 14 dias)</div><Bars data={sum.chart} /></div></div>}
      <div className="card"><div className="row">
        <div><label>Relatório</label><select value={type} onChange={(e) => { setType(e.target.value); setCat(""); }}>{TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></div>
        <div><label>De</label><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div><div><label>Até</label><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <div><label>Funcionário</label><select value={user} onChange={(e) => setUser(e.target.value)}><option value="">Todos</option>{rep?.users?.map((u: any) => <option key={u.id} value={u.id}>{u.full_name}</option>)}</select></div>
        {cats.length > 0 && <div><label>Categoria</label><select value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Todas</option>{cats.map((c) => <option key={c}>{c}</option>)}</select></div>}
      </div><button className="btn green" style={{ marginTop: 10 }} onClick={run}>Aplicar filtros</button></div>
      {rep && <div className="card tablewrap"><div className="mut" style={{ marginBottom: 6 }}>{rep.rows.length} registro(s) (máx. 500)</div>{rep.chart.length > 0 && <Bars data={rep.chart} />}
        <table><thead><tr><th>Data</th><th>Funcionário</th><th>Tipo</th><th>Detalhe</th></tr></thead><tbody>{rep.rows.map((r: any, i: number) => <tr key={i}><td>{fmtDate(r.at)}</td><td>{r.who}</td><td>{r.what}</td><td>{r.detail}</td></tr>)}</tbody></table></div>}
    </div>
  );
}
