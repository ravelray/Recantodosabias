import { redirect } from "next/navigation";
import { getSession, allowedPerms } from "@/lib/auth";
import Shell from "@/components/Shell";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession();
  if (!s) redirect("/login");
  const perms = await allowedPerms(s.role);
  return <Shell me={{ name: s.fullName, role: s.role, perms }}>{children}</Shell>;
}
