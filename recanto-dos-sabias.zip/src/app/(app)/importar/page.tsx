"use client";
import { useState } from "react";
import Papa from "papaparse";
import readXlsxFile from "read-excel-file";
import { j } from "@/lib/client";

export default function Importar() {
  const [rows, setRows] = useState<any[]>([]), [prev, setPrev] = useState<any>(null), [err, setErr] = useState(""), [msg, setMsg] = useState(""), [busy, setBusy] = useState(false);
  const clean = (k: string) => k.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    setErr(""); setMsg(""); setPrev(null); setBusy(true);
    try {
      let data: any[] = [];
      if (file.name.toLowerCase().endsWith(".csv")) {
        const text = await file.text();
        data = Papa.parse(text, { header: true, skipEmptyLines: true, transformHeader: clean }).data as any[];
      } else if (/\.xlsx$/i.test(file.name)) {
        const sheet = await readXlsxFile(file);
        const head = sheet[0].map((h) => clean(String(h ?? "")));
        data = sheet.slice(1).map((r) => Object.fromEntries(head.map((h, i) => [h, r[i] == null ? "" : String(r[i])])));
      } else throw new Error("Use um arquivo .csv ou .xlsx");
      if (data.length === 0) throw new Error("A planilha está vazia");
      if (data.length > 2000) throw new Error("Máximo de 2000 linhas por importação");
      setRows(data); setPrev(await j("/api/import/preview", { method: "POST", body: { rows: data } }));
    } catch (e: any) { setErr(e.message); }
    setBusy(false);
  }
  async function commit() {
    if (!confirm(`Gravar ${prev.summary.ok} morador(es)? Linhas com erro ou duplicadas serão ignoradas.`)) return;
    setBusy(true); setErr("");
    try { const r = await j("/api/import/commit", { method: "POST", body: { rows } }); setMsg(`Importação concluída: ${r.created} gravado(s), ${r.skipped} ignorado(s).`); setPrev(null); setRows([]); } catch (e: any) { setErr(e.message); }
    setBusy(false);
  }
  return (
    <div><h1>Importar moradores</h1>
      <div className="card"><p>Envie um arquivo <b>.csv</b> ou <b>.xlsx</b> com as colunas: <code>nome, bloco, apartamento, vinculo, email, telefone1, telefone2, telefone3, telefone4</code>.
        O sistema mostra a conferência antes de gravar. Nada existente é alterado ou apagado.</p>
        <input type="file" accept=".csv,.xlsx" onChange={onFile} disabled={busy} /></div>
      {err && <div className="err">{err}</div>}{msg && <div className="ok">{msg}</div>}{busy && <div className="mut">Processando...</div>}
      {prev && <div className="card tablewrap">
        <div className="row fit" style={{ marginBottom: 10 }}><span className="badge">{prev.summary.ok} prontos</span><span className="badge red">{prev.summary.errors} com erro</span><span className="badge amber">{prev.summary.duplicates} duplicados</span>
          <button className="btn green sm" disabled={prev.summary.ok === 0 || busy} onClick={commit}>Confirmar e gravar</button></div>
        <table><thead><tr><th>Linha</th><th>Nome</th><th>Bloco/Apto</th><th>Telefones</th><th>Situação</th></tr></thead><tbody>
          {prev.rows.map((r: any) => <tr key={r.line}><td>{r.line}</td><td>{r.name}</td><td>{r.block} / {r.apt}</td><td>{r.phones.length}</td>
            <td><span className={"badge " + (r.status === "OK" ? "" : r.status === "ERRO" ? "red" : "amber")}>{r.status}</span> <span className="mut">{r.messages.join("; ")}</span></td></tr>)}</tbody></table></div>}
    </div>
  );
}
