"use client";
import { useEffect, useState } from "react";
import { j, BOND } from "@/lib/client";
import { useCan } from "@/components/Shell";

const emptyPhone = () => ({ id: null as string | null, ownerName: "", ddd: "", number: "", kind: "CELULAR", label: "PRINCIPAL", isPriority: false, sharedWithUnit: false, active: true });
const empty = () => ({ fullName: "", cpf: "", block: "", apt: "", email: "", bond: "PROPRIETARIO", active: true, adminNote: "", phones: [emptyPhone()] });

export default function Moradores() {
  const can = useCan();
  const [q, setQ] = useState(""), [list, setList] = useState<any[]>([]), [err, setErr] = useState(""), [form, setForm] = useState<any>(null), [editId, setEditId] = useState<string | null>(null), [msg, setMsg] = useState("");

  async function load() { try { setList((await j(`/api/residents?q=${encodeURIComponent(q)}`)).residents); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [q]);

  async function edit(id: string) { setErr(""); try { setForm(await j(`/api/residents/${id}`)); setEditId(id); } catch (e: any) { setErr(e.message); } }
  const setF = (k: string, v: any) => setForm({ ...form, [k]: v });
  const setP = (i: number, k: string, v: any) => { const ph = [...form.phones]; ph[i] = { ...ph[i], [k]: v }; setForm({ ...form, phones: ph }); };
  async function save() {
    setErr("");
    const body = { ...form, phones: form.phones.filter((p: any) => p.ddd || p.number).map((p: any) => ({ ...p, ddd: p.ddd.replace(/\D/g, ""), number: p.number.replace(/\D/g, ""), ownerName: p.ownerName || form.fullName })) };
    try {
      await j(editId ? `/api/residents/${editId}` : "/api/residents", { method: editId ? "PUT" : "POST", body });
      setForm(null); setEditId(null); setMsg("Morador salvo."); load();
    } catch (e: any) { setErr(e.message); }
  }
  async function del(id: string) { if (!confirm("Excluir este morador? (exclusão lógica, fica no histórico)")) return; try { await j(`/api/residents/${id}`, { method: "DELETE" }); load(); } catch (e: any) { setErr(e.message); } }

  return (
    <div>
      <h1>Moradores</h1>
      <div className="row" style={{ marginBottom: 12 }}><input placeholder="Buscar por nome, bloco, apartamento ou telefone" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn green" style={{ flex: "0 0 auto" }} onClick={() => { setForm(empty()); setEditId(null); setErr(""); }}>+ Novo morador</button></div>
      {msg && <div className="ok">{msg}</div>}{!form && err && <div className="err">{err}</div>}
      <div className="card tablewrap"><table><thead><tr><th>Nome</th><th>Bloco</th><th>Apto</th><th>Vínculo</th><th>Tel.</th><th>Situação</th><th></th></tr></thead><tbody>
        {list.map((r) => <tr key={r.id}><td>{r.fullName}</td><td>{r.block}</td><td>{r.apt}</td><td>{BOND[r.bond]}</td><td>{r.phones}/4</td><td><span className={"badge " + (r.active ? "" : "gray")}>{r.active ? "Ativo" : "Inativo"}</span></td>
          <td style={{ whiteSpace: "nowrap" }}><button className="btn ghost sm" onClick={() => edit(r.id)}>Editar</button> {can("residents.delete") && <button className="btn red sm" onClick={() => del(r.id)}>Excluir</button>}</td></tr>)}
        {list.length === 0 && <tr><td colSpan={7} className="mut">Nenhum morador encontrado.</td></tr>}
      </tbody></table></div>

      {form && <div className="modal"><div className="box">
        <h2>{editId ? "Editar morador" : "Novo morador"}</h2>
        <label>Nome completo</label><input value={form.fullName} onChange={(e) => setF("fullName", e.target.value)} />
        <div className="row"><div><label>Bloco</label><input value={form.block} onChange={(e) => setF("block", e.target.value)} /></div><div><label>Apartamento</label><input value={form.apt} onChange={(e) => setF("apt", e.target.value)} /></div></div>
        <div className="row"><div><label>Vínculo</label><select value={form.bond} onChange={(e) => setF("bond", e.target.value)}><option value="PROPRIETARIO">Proprietário</option><option value="INQUILINO">Inquilino</option><option value="FAMILIAR">Familiar</option></select></div>
          <div><label>Situação</label><select value={form.active ? "1" : "0"} onChange={(e) => setF("active", e.target.value === "1")}><option value="1">Ativo</option><option value="0">Inativo</option></select></div></div>
        <div className="row"><div><label>CPF (opcional, restrito)</label><input value={form.cpf} onChange={(e) => setF("cpf", e.target.value)} inputMode="numeric" /></div><div><label>E-mail (opcional)</label><input value={form.email} onChange={(e) => setF("email", e.target.value)} /></div></div>
        <label>Observação administrativa</label><textarea rows={2} value={form.adminNote} onChange={(e) => setF("adminNote", e.target.value)} />
        <h2 style={{ marginTop: 16 }}>Telefones ({form.phones.length}/4)</h2>
        {form.phones.map((p: any, i: number) => (
          <div key={i} className="card" style={{ background: "#f8fafd" }}>
            <label>Responsável pelo número</label><input value={p.ownerName} onChange={(e) => setP(i, "ownerName", e.target.value)} placeholder="Nome (padrão: o morador)" />
            <div className="row"><div style={{ flex: "0 0 90px", minWidth: 80 }}><label>DDD</label><input value={p.ddd} onChange={(e) => setP(i, "ddd", e.target.value)} inputMode="numeric" maxLength={2} /></div><div><label>Número</label><input value={p.number} onChange={(e) => setP(i, "number", e.target.value)} inputMode="numeric" maxLength={10} /></div></div>
            <div className="row"><div><label>Tipo</label><select value={p.kind} onChange={(e) => setP(i, "kind", e.target.value)}><option value="CELULAR">Celular</option><option value="TELEFONE">Telefone</option></select></div>
              <div><label>Identificação</label><select value={p.label} onChange={(e) => setP(i, "label", e.target.value)}><option value="PRINCIPAL">Principal</option><option value="CONJUGE">Cônjuge</option><option value="FAMILIAR">Familiar</option><option value="OUTRO">Outro</option></select></div></div>
            <div className="row fit" style={{ marginTop: 6 }}>
              <label><input type="checkbox" style={{ width: "auto" }} checked={p.isPriority} onChange={(e) => setP(i, "isPriority", e.target.checked)} /> Prioritário</label>
              <label><input type="checkbox" style={{ width: "auto" }} checked={p.sharedWithUnit} onChange={(e) => setP(i, "sharedWithUnit", e.target.checked)} /> Compartilhado com a unidade</label>
              <label><input type="checkbox" style={{ width: "auto" }} checked={p.active} onChange={(e) => setP(i, "active", e.target.checked)} /> Ativo</label>
              <button className="btn red sm" onClick={() => setForm({ ...form, phones: form.phones.filter((_: any, k: number) => k !== i) })}>Remover</button></div>
          </div>))}
        <button className="btn ghost sm" disabled={form.phones.length >= 4} onClick={() => setForm({ ...form, phones: [...form.phones, emptyPhone()] })}>+ Adicionar telefone</button>
        {err && <div className="err">{err}</div>}
        <div className="row fit" style={{ marginTop: 14 }}><button className="btn green" onClick={save}>Salvar</button><button className="btn ghost" onClick={() => setForm(null)}>Cancelar</button></div>
      </div></div>}
    </div>
  );
}
