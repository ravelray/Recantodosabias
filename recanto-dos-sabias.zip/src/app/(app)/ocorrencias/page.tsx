"use client";
import { useEffect, useState } from "react";
import { j, fmtDate, OCC_CATEGORIES } from "@/lib/client";
import { useCan } from "@/components/Shell";

const ST: Record<string, string> = { ABERTA: "Aberta", EM_ANALISE: "Em análise", RESOLVIDA: "Resolvida" };

export default function Ocorrencias() {
  const can = useCan();
  const [rows, setRows] = useState<any[]>([]), [status, setStatus] = useState(""), [err, setErr] = useState(""), [msg, setMsg] = useState("");
  const [f, setF] = useState({ category: OCC_CATEGORIES[0], description: "", block: "", apt: "" });
  async function load() { try { setRows((await j(`/api/occurrences?status=${status}`)).occurrences); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { load(); }, [status]);
  async function add() {
    setErr(""); setMsg("");
    try { await j("/api/occurrences", { method: "POST", body: f }); setF({ ...f, description: "", block: "", apt: "" }); setMsg("Ocorrência registrada."); load(); } catch (e: any) { setErr(e.message); }
  }
  async function setSt(id: string, s: string) { try { await j(`/api/occurrences/${id}`, { method: "PUT", body: { status: s } }); load(); } catch (e: any) { setErr(e.message); } }
  return (
    <div><h1>Ocorrências</h1>
      {can("occurrences.create") && <div className="card"><h2>Nova ocorrência</h2>
        <label>Categoria</label><select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{OCC_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
        <label>Descrição</label><textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        <div className="row"><div><label>Bloco (opcional)</label><input value={f.block} onChange={(e) => setF({ ...f, block: e.target.value })} /></div><div><label>Apartamento (opcional)</label><input value={f.apt} onChange={(e) => setF({ ...f, apt: e.target.value })} /></div></div>
        {err && <div className="err">{err}</div>}{msg && <div className="ok">{msg}</div>}
        <button className="btn green" style={{ marginTop: 10 }} disabled={f.description.trim().length < 3} onClick={add}>Registrar ocorrência</button></div>}
      <div className="row" style={{ marginBottom: 10 }}><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Todas</option><option value="ABERTA">Abertas</option><option value="EM_ANALISE">Em análise</option><option value="RESOLVIDA">Resolvidas</option></select></div>
      {rows.map((o) => (
        <div key={o.id} className="card"><span className={"badge " + (o.status === "RESOLVIDA" ? "" : o.status === "ABERTA" ? "red" : "amber")}>{ST[o.status]}</span> <b>{o.category}</b> <span className="mut">{o.block ? `Bloco ${o.block} · Apto ${o.apt}` : ""}</span>
          <div style={{ margin: "6px 0" }}>{o.description}</div><div className="mut">{o.author} · {fmtDate(o.occurred_at)}</div>
          {can("occurrences.manage") && <div className="row fit" style={{ marginTop: 6 }}>{["ABERTA", "EM_ANALISE", "RESOLVIDA"].filter((s) => s !== o.status).map((s) => <button key={s} className="btn ghost sm" onClick={() => setSt(o.id, s)}>Marcar: {ST[s]}</button>)}</div>}</div>))}
      {rows.length === 0 && <div className="card mut">Nenhuma ocorrência.</div>}
    </div>
  );
}
