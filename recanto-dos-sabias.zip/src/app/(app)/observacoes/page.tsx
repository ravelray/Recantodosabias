"use client";
import { useEffect, useState } from "react";
import { j, fmtDate, OBS_CATEGORIES } from "@/lib/client";
import { useCan } from "@/components/Shell";

export default function Observacoes() {
  const can = useCan();
  const [q, setQ] = useState(""), [rows, setRows] = useState<any[]>([]), [err, setErr] = useState(""), [edit, setEdit] = useState<any>(null);
  async function load() { try { setRows((await j(`/api/observations?q=${encodeURIComponent(q)}`)).observations); } catch (e: any) { setErr(e.message); } }
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [q]);
  async function save() { try { await j(`/api/observations/${edit.id}`, { method: "PUT", body: { category: edit.category, body: edit.body } }); setEdit(null); load(); } catch (e: any) { setErr(e.message); } }
  async function del(id: string) { if (!confirm("Excluir esta observação?")) return; try { await j(`/api/observations/${id}`, { method: "DELETE" }); load(); } catch (e: any) { setErr(e.message); } }
  return (
    <div><h1>Observações da portaria</h1>
      <p className="mut">Para registrar uma observação, busque o morador na tela da Portaria e use “Anotar observação”. Observações não alteram o cadastro oficial.</p>
      <input placeholder="Buscar no texto ou pelo nome do morador" value={q} onChange={(e) => setQ(e.target.value)} style={{ marginBottom: 12 }} />
      {err && <div className="err">{err}</div>}
      {rows.map((o) => (
        <div key={o.id} className="card">
          {edit?.id === o.id ? (<>
            <select value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value })}>{OBS_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
            <textarea rows={3} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} style={{ marginTop: 6 }} />
            <div className="row fit" style={{ marginTop: 6 }}><button className="btn green sm" onClick={save}>Salvar</button><button className="btn ghost sm" onClick={() => setEdit(null)}>Cancelar</button></div></>) : (<>
            <span className="badge">{o.category}</span> <b>{o.resident || ""}</b> <span className="mut">{o.block ? `Bloco ${o.block} · Apto ${o.apt}` : ""}</span>
            <div style={{ margin: "6px 0" }}>{o.body}</div>
            <div className="mut">{o.author} · {fmtDate(o.created_at)}{o.updated_at ? " (editada)" : ""}</div>
            <div className="row fit" style={{ marginTop: 6 }}>
              {can("observations.edit") && <button className="btn ghost sm" onClick={() => setEdit({ id: o.id, category: o.category, body: o.body })}>Editar</button>}
              {can("observations.delete") && <button className="btn red sm" onClick={() => del(o.id)}>Excluir</button>}</div></>)}
        </div>))}
      {rows.length === 0 && <div className="card mut">Nenhuma observação encontrada.</div>}
    </div>
  );
}
