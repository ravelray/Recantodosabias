"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { j, fmtPhone, fmtDate, BOND, LABEL, OBS_CATEGORIES } from "@/lib/client";

export default function Portaria() {
  const [q, setQ] = useState(""), [block, setBlock] = useState(""), [apt, setApt] = useState("");
  const [blocks, setBlocks] = useState<{ id: number; name: string }[]>([]);
  const [res, setRes] = useState<any[]>([]), [canNote, setCanNote] = useState(false), [loading, setLoading] = useState(false), [err, setErr] = useState("");
  const [toast, setToast] = useState(""), [noteFor, setNoteFor] = useState<string | null>(null);
  const [nCat, setNCat] = useState(OBS_CATEGORIES[0]), [nBody, setNBody] = useState("");
  const [recent, setRecent] = useState<any[] | null>(null);
  const inp = useRef<HTMLInputElement>(null);
  const seq = useRef(0);

  useEffect(() => { j("/api/units").then((d) => setBlocks(d.blocks)).catch(() => {}); inp.current?.focus(); }, []);
  useEffect(() => {
    if (!q.trim() && !block && !apt) { setRes([]); return; }
    const my = ++seq.current;
    const t = setTimeout(async () => {
      setLoading(true); setErr("");
      try {
        const d = await j(`/api/search?q=${encodeURIComponent(q)}&block=${encodeURIComponent(block)}&apt=${encodeURIComponent(apt)}`);
        if (my === seq.current) { setRes(d.results); setCanNote(d.canNote); }
      } catch (e: any) { setErr(e.message); }
      if (my === seq.current) setLoading(false);
    }, 250);
    return () => clearTimeout(t);
  }, [q, block, apt]);

  const log = (action: string, r: any, p: any) => j("/api/attendance", { method: "POST", body: { action, residentId: r.id, unitId: r.unitId, phoneId: p.id } }).catch(() => {});
  const full = (p: any) => `55${p.ddd}${p.number}`;
  async function copy(r: any, p: any) {
    try { await navigator.clipboard.writeText(`${p.ddd}${p.number}`); setToast("Telefone copiado"); } catch { setToast("Não foi possível copiar"); }
    log("COPIAR_TELEFONE", r, p); setTimeout(() => setToast(""), 2500);
  }
  async function saveNote(r: any) {
    try {
      await j("/api/observations", { method: "POST", body: { residentId: r.id, unitId: r.unitId, category: nCat, body: nBody } });
      setNoteFor(null); setNBody(""); setToast("Observação registrada"); setTimeout(() => setToast(""), 2500);
      const d = await j(`/api/search?q=${encodeURIComponent(q)}&block=${encodeURIComponent(block)}&apt=${encodeURIComponent(apt)}`); setRes(d.results);
    } catch (e: any) { setErr(e.message); }
  }

  return (
    <div>
      <input ref={inp} className="search" placeholder="BUSCAR MORADOR, BLOCO, APARTAMENTO OU TELEFONE" value={q} onChange={(e) => setQ(e.target.value)} inputMode="search" />
      <div className="row" style={{ margin: ".6rem 0" }}>
        <select value={block} onChange={(e) => setBlock(e.target.value)}><option value="">Todos os blocos</option>{blocks.map((b) => <option key={b.id} value={b.name}>Bloco {b.name}</option>)}</select>
        <input placeholder="Apartamento" value={apt} onChange={(e) => setApt(e.target.value)} />
      </div>
      <div className="row fit" style={{ marginBottom: 12 }}>
        <button className="btn green" onClick={() => inp.current?.focus()}>🔎 Buscar morador</button>
        <Link className="btn ghost" href="/ocorrencias">⚠️ Registrar ocorrência</Link>
        <button className="btn ghost" onClick={async () => setRecent(recent ? null : (await j("/api/attendance")).items)}>🕘 Últimos atendimentos</button>
      </div>
      {recent && <div className="card"><h2>Últimos atendimentos</h2>{recent.length === 0 ? <div className="mut">Nenhum atendimento ainda.</div> :
        recent.map((r) => <div key={r.id} className="mut" style={{ padding: "4px 0" }}>{fmtDate(r.created_at)} — {r.who}: {r.action === "WHATSAPP" ? "WhatsApp" : r.action === "LIGACAO_WHATSAPP" ? "Ligação" : "Copiou telefone"} · {r.resident} ({r.block} {r.apt})</div>)}</div>}
      {err && <div className="err">{err}</div>}
      {toast && <div className="ok">{toast}</div>}
      {loading && <div className="mut">Buscando...</div>}
      {!loading && (q.trim() || block || apt) && res.length === 0 && !err && <div className="card">Nenhum morador encontrado. Confira o nome, o bloco ou o número.</div>}
      <div className="grid2">
        {res.map((r) => (
          <div key={r.id} className="card res">
            <div className="row" style={{ alignItems: "center" }}><h3>{r.fullName}</h3><span className="badge gray" style={{ flex: "0 0 auto" }}>{BOND[r.bond]}</span></div>
            <div className="unit">Bloco {r.block} · Apto {r.apt}</div>
            <div className="mut">{r.contactCount} contato(s) cadastrado(s)</div>
            {r.phones.length === 0 && <div className="mut" style={{ marginTop: 8 }}>Sem telefones disponíveis para você.</div>}
            {r.phones.map((p: any) => (
              <div key={p.id} className="phone">
                <div><span className="num">{fmtPhone(p.ddd, p.number)}</span> {p.isPriority && <span className="badge">Prioritário</span>} <span className="badge gray">{LABEL[p.label]}</span></div>
                <div className="mut">{p.ownerName}</div>
                <div className="acts">
                  <a className="btn green sm" href={`https://wa.me/${full(p)}`} target="_blank" rel="noopener noreferrer" onClick={() => log("WHATSAPP", r, p)}>💬 WhatsApp</a>
                  <a className="btn sm" href={`whatsapp://send?phone=${full(p)}`} onClick={() => { log("LIGACAO_WHATSAPP", r, p); setToast("WhatsApp aberto no contato: confirme a chamada no aplicativo."); setTimeout(() => setToast(""), 5000); }}>📞 Ligar pelo WhatsApp</a>
                  <button className="btn ghost sm" onClick={() => copy(r, p)}>📋 Copiar</button>
                </div>
              </div>
            ))}
            {r.notes.map((n: any) => <div key={n.id} className="note"><b>{n.category}</b>: {n.body}<div className="mut">{n.author} · {fmtDate(n.createdAt)}</div></div>)}
            {canNote && (noteFor === r.id ? (
              <div style={{ marginTop: 8 }}>
                <select value={nCat} onChange={(e) => setNCat(e.target.value)}>{OBS_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
                <textarea rows={2} placeholder="Observação" value={nBody} onChange={(e) => setNBody(e.target.value)} style={{ marginTop: 6 }} />
                <div className="row fit" style={{ marginTop: 6 }}><button className="btn green sm" disabled={nBody.trim().length < 2} onClick={() => saveNote(r)}>Salvar</button><button className="btn ghost sm" onClick={() => setNoteFor(null)}>Cancelar</button></div>
              </div>
            ) : <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={() => { setNoteFor(r.id); setNBody(""); }}>📝 Anotar observação</button>)}
          </div>
        ))}
      </div>
    </div>
  );
}
