export default function Privacidade() {
  return (
    <div><h1>Política de privacidade e LGPD</h1>
      <div className="card">
        <p>Este sistema é de uso interno do Condomínio Recanto dos Sabiás e trata dados de moradores (LGPD, Lei 13.709/2018) apenas para a finalidade de identificar a unidade e contatar o morador na rotina da portaria e da administração.</p>
        <h2>Dados tratados</h2><p>Nome, bloco, apartamento, vínculo, telefones e, opcionalmente, e-mail e CPF. O CPF é guardado criptografado e só aparece para quem tem permissão de cadastro; nunca na tela da portaria.</p>
        <h2>Acesso</h2><p>Cada funcionário tem conta própria e vê apenas o que seu perfil permite. Os dados não são públicos. Todas as ações relevantes ficam registradas na auditoria.</p>
        <h2>O que não é guardado</h2><p>O sistema registra apenas o clique em WhatsApp, ligação ou cópia de telefone. Conteúdo de conversas ou chamadas feitas no WhatsApp não é acessado nem armazenado.</p>
        <h2>Direitos dos titulares</h2><p>O morador pode pedir à Administração a correção, atualização ou exclusão de seus dados. Exclusões são lógicas e preservam o histórico necessário de auditoria.</p>
        <p className="mut">Revise este texto com o responsável legal do condomínio antes do uso oficial.</p>
      </div></div>
  );
}
