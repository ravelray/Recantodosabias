import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { residentSchema, saveResident } from "@/lib/residents";

export const GET = api("residents.manage", async ({ params }) => {
  const r = await sql`select r.*, b.name as block, u.number as apt from residents r join units u on u.id = r.unit_id join blocks b on b.id = u.block_id
    where r.id = ${params.id} and r.deleted_at is null`;
  if (!r[0]) throw new HttpError(404, "Morador não encontrado");
  const phones = await sql`select id, owner_name, ddd, number, kind, label, is_priority, shared_with_unit, active from phones
    where resident_id = ${params.id} and deleted_at is null order by created_at`;
  let cpf = "";
  try { cpf = r[0].cpf_encrypted ? decrypt(r[0].cpf_encrypted) : ""; } catch { cpf = ""; }
  return {
    id: r[0].id, fullName: r[0].full_name, cpf, block: r[0].block, apt: r[0].apt, email: r[0].email || "", bond: r[0].bond,
    active: r[0].active, adminNote: r[0].admin_note || "",
    phones: phones.map((p) => ({ id: p.id, ownerName: p.owner_name, ddd: p.ddd, number: p.number, kind: p.kind, label: p.label, isPriority: p.is_priority, sharedWithUnit: p.shared_with_unit, active: p.active })),
  };
});

export const PUT = api("residents.manage", async ({ s, req, params }) => {
  const d = residentSchema.parse(await body(req));
  await saveResident(s.userId, params.id, d);
  await audit(s.userId, "RESIDENT_UPDATE", "resident", params.id, null, { fullName: d.fullName, block: d.block, apt: d.apt, phones: d.phones.length, active: d.active });
  return { ok: true };
});

export const DELETE = api("residents.delete", async ({ s, params }) => {
  const r = await sql`update residents set deleted_at = now(), active = false where id = ${params.id} and deleted_at is null returning full_name`;
  if (!r[0]) throw new HttpError(404, "Morador não encontrado");
  await sql`update phones set deleted_at = now() where resident_id = ${params.id} and deleted_at is null`;
  await audit(s.userId, "RESIDENT_DELETE", "resident", params.id, { fullName: r[0].full_name }, null);
  return { ok: true };
});
