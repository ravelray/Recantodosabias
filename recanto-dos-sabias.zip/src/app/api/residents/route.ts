import { api, audit, body } from "@/lib/api";
import { sql } from "@/lib/db";
import { searchResidents } from "@/lib/search";
import { residentSchema, saveResident } from "@/lib/residents";

export const GET = api("residents.manage", async ({ req }) => {
  const u = new URL(req.url);
  const rows = await searchResidents({ q: u.searchParams.get("q") || "", includeInactive: true, limit: 60 });
  const ids = rows.map((r) => r.id);
  const counts = ids.length
    ? await sql`select resident_id, count(*)::int as c from phones where deleted_at is null and resident_id = any(${ids}::uuid[]) group by resident_id`
    : [];
  return {
    residents: rows.map((r) => ({
      id: r.id, fullName: r.full_name, bond: r.bond, active: r.active, block: r.block, apt: r.apt,
      phones: counts.find((c) => c.resident_id === r.id)?.c ?? 0,
    })),
  };
});

export const POST = api("residents.manage", async ({ s, req }) => {
  const d = residentSchema.parse(await body(req));
  const id = await saveResident(s.userId, null, d);
  await audit(s.userId, "RESIDENT_CREATE", "resident", id, null, { fullName: d.fullName, block: d.block, apt: d.apt, phones: d.phones.length });
  return { id };
});
