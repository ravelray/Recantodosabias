import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { sql } from "@/lib/db";
import { sha } from "@/lib/auth";
import { audit } from "@/lib/api";

const schema = z.object({ token: z.string().min(20).max(200), password: z.string().min(10).max(200) });

export async function POST(req: Request) {
  const p = schema.safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "A senha deve ter pelo menos 10 caracteres" }, { status: 400 });
  const r = await sql`select id, user_id from password_resets where token_hash = ${sha(p.data.token)} and used_at is null and expires_at > now()`;
  if (!r[0]) return NextResponse.json({ error: "Link inválido ou expirado. Peça um novo à Administração." }, { status: 400 });
  const hash = await bcrypt.hash(p.data.password, 12);
  await sql`update users set password_hash = ${hash}, updated_at = now() where id = ${r[0].user_id}`;
  await sql`update password_resets set used_at = now() where id = ${r[0].id}`;
  await sql`update sessions set revoked_at = now() where user_id = ${r[0].user_id} and revoked_at is null`;
  await audit(r[0].user_id, "PASSWORD_RESET", "user", r[0].user_id);
  return NextResponse.json({ ok: true });
}
