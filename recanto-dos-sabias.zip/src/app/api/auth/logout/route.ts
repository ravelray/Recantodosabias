import { NextResponse } from "next/server";
import { getSession, destroySession } from "@/lib/auth";
import { audit } from "@/lib/api";

export async function POST() {
  const s = await getSession();
  if (s) await audit(s.userId, "LOGOUT", "user", s.userId);
  await destroySession();
  return NextResponse.json({ ok: true });
}
