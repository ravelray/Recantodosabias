import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { sql } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { audit, clientIp } from "@/lib/api";

const DUMMY = bcrypt.hashSync("dummy-password-for-timing", 10);
const schema = z.object({ identifier: z.string().min(1).max(100), password: z.string().min(1).max(200) });

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Informe usuário e senha" }, { status: 400 });
  const id = parsed.data.identifier.trim().toLowerCase();
  const ip = clientIp();

  // Controle de tentativas: 5 erros em 15 minutos bloqueiam novas tentativas desse usuário.
  const recent = await sql`select count(*)::int as c from login_attempts
    where lower(identifier) = ${id} and success = false and created_at > now() - interval '15 minutes'`;
  if (recent[0].c >= 5) {
    return NextResponse.json({ error: "Muitas tentativas. Aguarde 15 minutos ou peça ajuda à Administração." }, { status: 429 });
  }

  const rows = await sql`select id, password_hash, active from users
    where deleted_at is null and (lower(username) = ${id} or lower(email) = ${id})`;
  const u = rows[0];
  const ok = await bcrypt.compare(parsed.data.password, u?.password_hash ?? DUMMY);
  if (!u || !ok || !u.active) {
    await sql`insert into login_attempts(identifier, ip, success) values (${id}, ${ip}, false)`;
    return NextResponse.json({ error: "Usuário ou senha inválidos" }, { status: 401 });
  }
  await sql`insert into login_attempts(identifier, ip, success) values (${id}, ${ip}, true)`;
  await sql`update users set last_login_at = now() where id = ${u.id}`;
  await createSession(u.id, ip, req.headers.get("user-agent"));
  await audit(u.id, "LOGIN", "user", u.id);
  return NextResponse.json({ ok: true });
}
