import { z } from "zod";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";

export const PUT = api("observations.edit", async ({ s, req, params }) => {
  const d = z.object({ category: z.string().min(1).max(60), body: z.string().trim().min(2).max(1000) }).parse(await body(req));
  const r = await sql`update observations set category = ${d.category}, body = ${d.body}, updated_at = now() where id = ${params.id} and deleted_at is null returning id`;
  if (!r[0]) throw new HttpError(404, "Observação não encontrada");
  await audit(s.userId, "OBSERVATION_UPDATE", "observation", params.id);
  return { ok: true };
});
export const DELETE = api("observations.delete", async ({ s, params }) => {
  const r = await sql`update observations set deleted_at = now() where id = ${params.id} and deleted_at is null returning id`;
  if (!r[0]) throw new HttpError(404, "Observação não encontrada");
  await audit(s.userId, "OBSERVATION_DELETE", "observation", params.id);
  return { ok: true };
});
