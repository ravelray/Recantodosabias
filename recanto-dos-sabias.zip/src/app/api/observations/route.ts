import { z } from "zod";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api("residents.search", async ({ req }) => {
  const q = (new URL(req.url).searchParams.get("q") || "").toLowerCase();
  const rows = await sql`select o.id, o.category, o.body, o.created_at, o.updated_at, o.created_by, us.full_name as author,
      r.full_name as resident, b.name as block, un.number as apt
    from observations o join users us on us.id = o.created_by
      left join residents r on r.id = o.resident_id
      left join units un on un.id = coalesce(o.unit_id, r.unit_id) left join blocks b on b.id = un.block_id
    where o.deleted_at is null and (${q} = '' or lower(o.body) like '%' || ${q} || '%' or lower(coalesce(r.full_name, '')) like '%' || ${q} || '%')
    order by o.created_at desc limit 100`;
  return { observations: rows };
});

const schema = z.object({
  unitId: z.number().int().optional().nullable(), residentId: z.string().uuid().optional().nullable(),
  category: z.string().min(1).max(60), body: z.string().trim().min(2).max(1000),
});
export const POST = api("observations.create", async ({ s, req }) => {
  const d = schema.parse(await body(req));
  if (!d.unitId && !d.residentId) throw new HttpError(400, "Informe o morador ou a unidade");
  const r = await sql`insert into observations(resident_id, unit_id, category, body, created_by)
    values (${d.residentId ?? null}, ${d.unitId ?? null}, ${d.category}, ${d.body}, ${s.userId}) returning id`;
  await audit(s.userId, "OBSERVATION_CREATE", "observation", r[0].id, null, { category: d.category });
  return { id: r[0].id };
});
