import { z } from "zod";
import { api, body } from "@/lib/api";
import { can } from "@/lib/auth";
import { sql } from "@/lib/db";

// Registra só o clique (WhatsApp, ligação, copiar). Nada do conteúdo da conversa é guardado.
export const POST = api("residents.search", async ({ s, req }) => {
  const d = z.object({
    action: z.enum(["WHATSAPP", "LIGACAO_WHATSAPP", "COPIAR_TELEFONE"]),
    residentId: z.string().uuid(), unitId: z.number().int(), phoneId: z.string().uuid().optional().nullable(),
  }).parse(await body(req));
  await sql`insert into attendance_log(user_id, resident_id, unit_id, action, phone_id) values (${s.userId}, ${d.residentId}, ${d.unitId}, ${d.action}, ${d.phoneId ?? null})`;
  return { ok: true };
});

export const GET = api("residents.search", async ({ s }) => {
  const all = await can(s.role, "reports.view");
  const rows = await sql`select al.id, al.action, al.created_at, u.full_name as who, r.full_name as resident, b.name as block, un.number as apt
    from attendance_log al join users u on u.id = al.user_id left join residents r on r.id = al.resident_id
      left join units un on un.id = coalesce(al.unit_id, r.unit_id) left join blocks b on b.id = un.block_id
    where al.action <> 'CONSULTA' and (${all}::boolean or al.user_id = ${s.userId}::uuid)
    order by al.created_at desc limit 20`;
  return { items: rows };
});
