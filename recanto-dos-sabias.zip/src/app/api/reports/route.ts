import { api } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api("reports.view", async ({ req }) => {
  const u = new URL(req.url).searchParams;
  const type = u.get("type") || "resumo";
  const from = u.get("from") || "2000-01-01", to = u.get("to") || "2999-12-31";
  const user = u.get("userId") || null, cat = u.get("category") || null;

  if (type === "resumo") {
    const r = await sql`select
      (select count(*)::int from residents where deleted_at is null and active) as residents,
      (select count(*)::int from attendance_log where action <> 'CONSULTA' and created_at > now() - interval '30 days') as atendimentos,
      (select count(*)::int from attendance_log where action = 'CONSULTA' and created_at > now() - interval '30 days') as consultas,
      (select count(*)::int from occurrences where deleted_at is null and status <> 'RESOLVIDA') as occ_open,
      (select count(*)::int from users where deleted_at is null and active) as users`;
    const days = await sql`select to_char(d, 'DD/MM') as label, (select count(*)::int from attendance_log a where a.action <> 'CONSULTA' and a.created_at::date = d) as total
      from generate_series(current_date - 13, current_date, '1 day') d order by d`;
    return { summary: r[0], chart: days };
  }

  let rows: any[] = [];
  if (type === "atendimentos" || type === "consultas") {
    const isQ = type === "consultas";
    rows = await sql`select al.created_at as at, u.full_name as who, al.action as what, coalesce(r.full_name, '') || ' — ' || coalesce(b.name || ' ' || un.number, '') as detail
      from attendance_log al join users u on u.id = al.user_id left join residents r on r.id = al.resident_id
        left join units un on un.id = coalesce(al.unit_id, r.unit_id) left join blocks b on b.id = un.block_id
      where (al.action = 'CONSULTA') = ${isQ}::boolean and al.created_at >= ${from}::date and al.created_at < (${to}::date + 1)
        and (${user}::uuid is null or al.user_id = ${user}::uuid) order by al.created_at desc limit 500`;
  } else if (type === "observacoes") {
    rows = await sql`select o.created_at as at, u.full_name as who, o.category as what, o.body as detail from observations o join users u on u.id = o.created_by
      where o.deleted_at is null and o.created_at >= ${from}::date and o.created_at < (${to}::date + 1)
        and (${user}::uuid is null or o.created_by = ${user}::uuid) and (${cat}::text is null or o.category = ${cat}) order by o.created_at desc limit 500`;
  } else if (type === "ocorrencias") {
    rows = await sql`select o.occurred_at as at, u.full_name as who, o.category || ' (' || o.status || ')' as what, o.description as detail from occurrences o join users u on u.id = o.created_by
      where o.deleted_at is null and o.occurred_at >= ${from}::date and o.occurred_at < (${to}::date + 1)
        and (${user}::uuid is null or o.created_by = ${user}::uuid) and (${cat}::text is null or o.category = ${cat}) order by o.occurred_at desc limit 500`;
  } else if (type === "alteracoes") {
    rows = await sql`select a.created_at as at, u.full_name as who, a.action as what, a.entity || ' ' || coalesce(a.entity_id, '') as detail from audit_logs a left join users u on u.id = a.user_id
      where a.entity in ('resident', 'unit', 'user', 'permission') and a.created_at >= ${from}::date and a.created_at < (${to}::date + 1)
        and (${user}::uuid is null or a.user_id = ${user}::uuid) order by a.created_at desc limit 500`;
  } else if (type === "acessos") {
    rows = await sql`select a.created_at as at, u.full_name as who, a.action as what, coalesce(a.ip, '') as detail from audit_logs a left join users u on u.id = a.user_id
      where a.action in ('LOGIN', 'LOGOUT') and a.created_at >= ${from}::date and a.created_at < (${to}::date + 1)
        and (${user}::uuid is null or a.user_id = ${user}::uuid) order by a.created_at desc limit 500`;
  }
  const byDay: Record<string, number> = {};
  for (const r of rows) { const k = new Date(r.at).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }); byDay[k] = (byDay[k] || 0) + 1; }
  const users = await sql`select id, full_name from users where deleted_at is null order by full_name`;
  return { rows, chart: Object.entries(byDay).reverse().map(([label, total]) => ({ label, total })), users };
});
