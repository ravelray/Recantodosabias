import { api } from "@/lib/api";
import { can } from "@/lib/auth";
import { sql } from "@/lib/db";
import { searchResidents } from "@/lib/search";

export const GET = api("residents.search", async ({ s, req }) => {
  const u = new URL(req.url);
  const q = u.searchParams.get("q") || "";
  const rows = await searchResidents({ q, block: u.searchParams.get("block") || "", apt: u.searchParams.get("apt") || "", limit: 30 });
  const canPhones = await can(s.role, "residents.view_phones");
  const canNote = await can(s.role, "observations.create");
  if (!rows.length) return { results: [], canNote };
  const ids = rows.map((r) => r.id);
  const unitIds = [...new Set(rows.map((r) => r.unit_id))];

  let phones: any[] = [];
  if (canPhones) {
    // Telefone marcado como "compartilhado" aparece para todos os moradores da mesma unidade.
    phones = await sql`select p.id, p.resident_id, r2.unit_id, p.owner_name, p.ddd, p.number, p.kind, p.label, p.is_priority, p.shared_with_unit
      from phones p join residents r2 on r2.id = p.resident_id
      where p.deleted_at is null and p.active and r2.deleted_at is null
        and (p.resident_id = any(${ids}::uuid[]) or (p.shared_with_unit and r2.unit_id = any(${unitIds}::int[])))
      order by p.is_priority desc, p.created_at`;
  }
  const obs = await sql`select o.id, o.resident_id, o.unit_id, o.category, o.body, o.created_at, us.full_name as author
    from observations o join users us on us.id = o.created_by
    where o.deleted_at is null and (o.resident_id = any(${ids}::uuid[]) or o.unit_id = any(${unitIds}::int[]))
    order by o.created_at desc limit 100`;

  const results = rows.map((r) => {
    const mine = phones.filter((p) => p.resident_id === r.id || (p.shared_with_unit && p.unit_id === r.unit_id));
    const seen = new Set<string>();
    const unique = mine.filter((p) => (seen.has(p.id) ? false : (seen.add(p.id), true)));
    return {
      id: r.id, fullName: r.full_name, bond: r.bond, block: r.block, apt: r.apt, unitId: r.unit_id,
      contactCount: unique.length,
      phones: unique.map((p) => ({ id: p.id, ownerName: p.owner_name, ddd: p.ddd, number: p.number, kind: p.kind, label: p.label, isPriority: p.is_priority })),
      notes: obs.filter((o) => o.resident_id === r.id || (!o.resident_id && o.unit_id === r.unit_id)).slice(0, 2)
        .map((o) => ({ id: o.id, category: o.category, body: o.body, author: o.author, createdAt: o.created_at })),
    };
  });
  if (q.trim().length >= 3) {
    await sql`insert into attendance_log(user_id, resident_id, unit_id, action) values (${s.userId}, ${rows[0].id}, ${rows[0].unit_id}, 'CONSULTA')`;
  }
  return { results, canNote };
});
