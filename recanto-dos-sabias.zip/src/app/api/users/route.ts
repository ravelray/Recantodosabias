import { z } from "zod";
import bcrypt from "bcryptjs";
import { api, audit, body } from "@/lib/api";
import { assertCanManage } from "@/lib/users";
import { can } from "@/lib/auth";
import { sql } from "@/lib/db";

export const GET = api(["users.manage_portaria", "users.manage_all"], async ({ s }) => {
  const all = await can(s.role, "users.manage_all");
  const rows = await sql`select id, username, email, full_name, role, active, last_login_at from users
    where deleted_at is null and (${all}::boolean or role = 'PORTARIA') and (role <> 'DESENVOLVEDOR' or ${s.role === "DESENVOLVEDOR"}::boolean)
    order by role, full_name`;
  return { users: rows.map((r) => ({ id: r.id, username: r.username, email: r.email, fullName: r.full_name, role: r.role, active: r.active, lastLoginAt: r.last_login_at })), me: s.userId };
});

const schema = z.object({
  username: z.string().trim().toLowerCase().regex(/^[a-z0-9._-]{3,30}$/, "Usuário: 3 a 30 letras minúsculas, números, ponto, hífen ou _"),
  fullName: z.string().trim().min(3).max(100),
  email: z.string().trim().email().optional().or(z.literal("")).nullable(),
  password: z.string().min(10, "A senha deve ter ao menos 10 caracteres").max(200),
  role: z.enum(["DESENVOLVEDOR", "ADMINISTRACAO", "PORTARIA"]),
});
export const POST = api(["users.manage_portaria", "users.manage_all"], async ({ s, req }) => {
  const d = schema.parse(await body(req));
  await assertCanManage(s, d.role);
  const hash = await bcrypt.hash(d.password, 12);
  const r = await sql`insert into users(username, email, full_name, password_hash, role, created_by)
    values (${d.username}, ${d.email || null}, ${d.fullName}, ${hash}, ${d.role}::role_kind, ${s.userId}) returning id`;
  await audit(s.userId, "USER_CREATE", "user", r[0].id, null, { username: d.username, role: d.role });
  return { id: r[0].id };
});
