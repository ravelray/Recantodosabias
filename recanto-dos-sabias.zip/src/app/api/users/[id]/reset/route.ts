import crypto from "crypto";
import { api, audit, HttpError } from "@/lib/api";
import { sha } from "@/lib/auth";
import { sql } from "@/lib/db";
import { assertCanManage } from "@/lib/users";

// Recuperação de senha: a Administração/Desenvolvedor gera um link de uso único (válido por 2 horas) e entrega ao funcionário.
export const POST = api(["users.manage_portaria", "users.manage_all"], async ({ s, req, params }) => {
  const t = await sql`select id, role from users where id = ${params.id} and deleted_at is null`;
  if (!t[0]) throw new HttpError(404, "Usuário não encontrado");
  await assertCanManage(s, t[0].role);
  const token = crypto.randomBytes(32).toString("hex");
  await sql`insert into password_resets(user_id, token_hash, expires_at) values (${params.id}, ${sha(token)}, now() + interval '2 hours')`;
  await audit(s.userId, "PASSWORD_RESET_LINK", "user", params.id);
  return { link: `${new URL(req.url).origin}/reset?token=${token}` };
});
