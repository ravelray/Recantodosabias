import { z } from "zod";
import bcrypt from "bcryptjs";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";
import { assertCanManage } from "@/lib/users";

async function target(id: string) {
  const r = await sql`select id, role, active from users where id = ${id} and deleted_at is null`;
  if (!r[0]) throw new HttpError(404, "Usuário não encontrado");
  return r[0];
}
const PERMS = ["users.manage_portaria", "users.manage_all"];

export const PUT = api(PERMS, async ({ s, req, params }) => {
  const d = z.object({
    fullName: z.string().trim().min(3).max(100).optional(), email: z.string().trim().email().optional().or(z.literal("")).nullable(),
    active: z.boolean().optional(), role: z.enum(["DESENVOLVEDOR", "ADMINISTRACAO", "PORTARIA"]).optional(),
    password: z.string().min(10).max(200).optional(),
  }).parse(await body(req));
  const t = await target(params.id);
  await assertCanManage(s, t.role);
  if (d.role) await assertCanManage(s, d.role);
  if (params.id === s.userId && (d.active === false || (d.role && d.role !== t.role))) throw new HttpError(400, "Você não pode bloquear a própria conta nem mudar o próprio perfil");
  const hash = d.password ? await bcrypt.hash(d.password, 12) : null;
  await sql`update users set full_name = coalesce(${d.fullName ?? null}, full_name), email = case when ${d.email !== undefined}::boolean then ${d.email || null} else email end,
      active = coalesce(${d.active ?? null}::boolean, active), role = coalesce(${d.role ?? null}::role_kind, role),
      password_hash = coalesce(${hash}, password_hash), updated_at = now() where id = ${params.id}`;
  if (d.active === false || hash) await sql`update sessions set revoked_at = now() where user_id = ${params.id} and revoked_at is null`;
  await audit(s.userId, d.active === false ? "USER_BLOCK" : d.active === true ? "USER_UNBLOCK" : "USER_UPDATE", "user", params.id, null, { role: d.role, passwordChanged: !!hash });
  return { ok: true };
});

export const DELETE = api(PERMS, async ({ s, params }) => {
  const t = await target(params.id);
  await assertCanManage(s, t.role);
  if (params.id === s.userId) throw new HttpError(400, "Você não pode excluir a própria conta");
  await sql`update users set deleted_at = now(), active = false where id = ${params.id}`;
  await sql`update sessions set revoked_at = now() where user_id = ${params.id} and revoked_at is null`;
  await audit(s.userId, "USER_DELETE", "user", params.id);
  return { ok: true };
});
