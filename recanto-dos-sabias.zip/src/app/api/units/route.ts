import { api } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api(["residents.search", "residents.manage"], async () => {
  const blocks = await sql`select id, name from blocks where deleted_at is null and active order by name`;
  const units = await sql`select u.id, u.number, b.name as block from units u join blocks b on b.id = u.block_id where u.deleted_at is null order by b.name, u.number`;
  return { blocks, units };
});
