import { z } from "zod";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api("permissions.manage", async ({ s }) => {
  const permissions = await sql`select code, description, grp from permissions order by grp, description`;
  const rp = await sql`select role, permission_code, allowed from role_permissions`;
  const matrix: Record<string, Record<string, boolean>> = { DESENVOLVEDOR: {}, ADMINISTRACAO: {}, PORTARIA: {} };
  for (const r of rp) matrix[r.role][r.permission_code] = r.allowed;
  return { permissions, matrix, myRole: s.role };
});

export const PUT = api("permissions.manage", async ({ s, req }) => {
  const d = z.object({ role: z.enum(["ADMINISTRACAO", "PORTARIA"]), code: z.string().min(1).max(80), allowed: z.boolean() }).parse(await body(req));
  if (d.role === "ADMINISTRACAO" && s.role !== "DESENVOLVEDOR") throw new HttpError(403, "Apenas o Desenvolvedor altera as permissões da Administração");
  const ex = await sql`select 1 from permissions where code = ${d.code}`;
  if (!ex[0]) throw new HttpError(400, "Permissão inexistente");
  await sql`insert into role_permissions(role, permission_code, allowed, updated_by, updated_at) values (${d.role}::role_kind, ${d.code}, ${d.allowed}, ${s.userId}, now())
    on conflict (role, permission_code) do update set allowed = excluded.allowed, updated_by = excluded.updated_by, updated_at = now()`;
  await audit(s.userId, "PERMISSION_CHANGE", "permission", `${d.role}:${d.code}`, null, { allowed: d.allowed });
  return { ok: true };
});
