import { z } from "zod";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";

export const PUT = api("occurrences.manage", async ({ s, req, params }) => {
  const d = z.object({ status: z.enum(["ABERTA", "EM_ANALISE", "RESOLVIDA"]) }).parse(await body(req));
  const r = await sql`update occurrences set status = ${d.status}::occurrence_status, updated_at = now(),
      resolved_by = case when ${d.status} = 'RESOLVIDA' then ${s.userId}::uuid else null end,
      resolved_at = case when ${d.status} = 'RESOLVIDA' then now() else null end
    where id = ${params.id} and deleted_at is null returning id`;
  if (!r[0]) throw new HttpError(404, "Ocorrência não encontrada");
  await audit(s.userId, "OCCURRENCE_STATUS", "occurrence", params.id, null, { status: d.status });
  return { ok: true };
});
