import { z } from "zod";
import { api, audit, body, HttpError } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api(["occurrences.create", "occurrences.manage"], async ({ req }) => {
  const st = new URL(req.url).searchParams.get("status") || "";
  const rows = await sql`select o.id, o.category, o.description, o.status, o.occurred_at, us.full_name as author, b.name as block, un.number as apt
    from occurrences o join users us on us.id = o.created_by left join units un on un.id = o.unit_id left join blocks b on b.id = un.block_id
    where o.deleted_at is null and (${st} = '' or o.status::text = ${st}) order by o.occurred_at desc limit 100`;
  return { occurrences: rows };
});

const schema = z.object({
  category: z.string().min(1).max(60), description: z.string().trim().min(3).max(2000),
  block: z.string().trim().max(30).optional().nullable(), apt: z.string().trim().max(20).optional().nullable(),
});
export const POST = api("occurrences.create", async ({ s, req }) => {
  const d = schema.parse(await body(req));
  let unitId: number | null = null;
  if (d.block && d.apt) {
    const u = await sql`select u.id from units u join blocks b on b.id = u.block_id where lower(b.name) = lower(${d.block}) and lower(u.number) = lower(${d.apt}) and u.deleted_at is null`;
    if (!u[0]) throw new HttpError(400, "Unidade não encontrada. Confira o bloco e o apartamento.");
    unitId = u[0].id;
  }
  const r = await sql`insert into occurrences(category, description, unit_id, created_by) values (${d.category}, ${d.description}, ${unitId}, ${s.userId}) returning id`;
  await audit(s.userId, "OCCURRENCE_CREATE", "occurrence", r[0].id, null, { category: d.category });
  return { id: r[0].id };
});
