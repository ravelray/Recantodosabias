import { api } from "@/lib/api";
import { sql } from "@/lib/db";

export const GET = api("audit.view", async ({ req }) => {
  const u = new URL(req.url).searchParams;
  const from = u.get("from") || "2000-01-01", to = u.get("to") || "2999-12-31", user = u.get("userId") || null;
  const rows = await sql`select a.id, a.created_at, a.action, a.entity, a.entity_id, a.after_data, a.ip, us.full_name as who
    from audit_logs a left join users us on us.id = a.user_id
    where a.created_at >= ${from}::date and a.created_at < (${to}::date + 1) and (${user}::uuid is null or a.user_id = ${user}::uuid)
    order by a.created_at desc limit 300`;
  const users = await sql`select id, full_name from users where deleted_at is null order by full_name`;
  return { rows, users };
});
