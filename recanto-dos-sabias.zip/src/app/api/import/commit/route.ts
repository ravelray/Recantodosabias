import { api, audit, body } from "@/lib/api";
import { sql } from "@/lib/db";
import { validateRows } from "@/lib/import";
import { findOrCreateUnit } from "@/lib/residents";

export const maxDuration = 60;
// Revalida tudo no servidor e só grava as linhas válidas e sem duplicidade. Nada existente é alterado ou apagado.
export const POST = api("import.run", async ({ s, req }) => {
  const { rows } = await body(req);
  const v = await validateRows(Array.isArray(rows) ? rows.slice(0, 2000) : []);
  let created = 0;
  for (const r of v.rows.filter((x) => x.status === "OK")) {
    const unitId = await findOrCreateUnit(r.block, r.apt);
    const ins = await sql`insert into residents(unit_id, full_name, email, bond, created_by) values (${unitId}, ${r.name}, ${r.email || null}, ${r.bond}::bond_kind, ${s.userId}) returning id`;
    let i = 0;
    for (const p of r.phones) {
      await sql`insert into phones(resident_id, owner_name, ddd, number, kind, label, is_priority)
        values (${ins[0].id}, ${r.name}, ${p.ddd}, ${p.number}, ${p.number.length === 9 ? "CELULAR" : "TELEFONE"}::phone_kind, ${i === 0 ? "PRINCIPAL" : "OUTRO"}::phone_label, ${i === 0})`;
      i++;
    }
    created++;
  }
  await audit(s.userId, "IMPORT_RESIDENTS", "resident", null, null, { created, skipped: v.rows.length - created });
  return { created, skipped: v.rows.length - created };
});
