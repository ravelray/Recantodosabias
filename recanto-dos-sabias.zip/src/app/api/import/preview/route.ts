import { api, body } from "@/lib/api";
import { validateRows } from "@/lib/import";

export const maxDuration = 60;
export const POST = api("import.run", async ({ req }) => {
  const { rows } = await body(req);
  return await validateRows(Array.isArray(rows) ? rows.slice(0, 2000) : []);
});
