"use client";
import { useState } from "react";

export default function Login() {
  const [identifier, setI] = useState(""), [password, setP] = useState(""), [err, setErr] = useState(""), [busy, setBusy] = useState(false), [help, setHelp] = useState(false);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr("");
    const r = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ identifier, password }) });
    const d = await r.json().catch(() => ({}));
    if (r.ok) window.location.href = "/"; else { setErr(d.error || "Erro ao entrar"); setBusy(false); }
  }
  return (
    <div className="login"><div className="box">
      <div style={{ textAlign: "center", marginBottom: 12 }}><div className="logo" style={{ margin: "0 auto 8px", width: 56, height: 56, fontSize: "1.8rem" }}>🌿</div>
        <h1 style={{ margin: 0 }}>Recanto dos Sabiás</h1><div className="mut">Acesso restrito à portaria e administração</div></div>
      <form onSubmit={go}>
        <label>Usuário ou e-mail</label><input value={identifier} onChange={(e) => setI(e.target.value)} autoComplete="username" autoCapitalize="none" required />
        <label>Senha</label><input type="password" value={password} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required />
        {err && <div className="err">{err}</div>}
        <button className="btn green" style={{ width: "100%", marginTop: 14 }} disabled={busy}>{busy ? "Entrando..." : "Entrar"}</button>
      </form>
      <p style={{ textAlign: "center" }}><a href="#" onClick={(e) => { e.preventDefault(); setHelp(!help); }}>Esqueci minha senha</a></p>
      {help && <div className="note">Peça à Administração um link de redefinição de senha. Ele vale por 2 horas e só pode ser usado uma vez.</div>}
    </div></div>
  );
}
