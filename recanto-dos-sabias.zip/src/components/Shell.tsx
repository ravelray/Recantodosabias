"use client";
import { createContext, useContext, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

type Me = { name: string; role: string; perms: string[] };
const Ctx = createContext<Me>({ name: "", role: "", perms: [] });
export const useMe = () => useContext(Ctx);
export const useCan = () => { const m = useMe(); return (c: string) => m.perms.includes(c); };

const ROLE: Record<string, string> = { DESENVOLVEDOR: "Desenvolvedor", ADMINISTRACAO: "Administração", PORTARIA: "Portaria" };
const ITEMS: { href: string; label: string; icon: string; need: string[] }[] = [
  { href: "/", label: "Portaria", icon: "🔎", need: ["residents.search"] },
  { href: "/moradores", label: "Moradores", icon: "👥", need: ["residents.manage"] },
  { href: "/observacoes", label: "Observações", icon: "📝", need: ["residents.search"] },
  { href: "/ocorrencias", label: "Ocorrências", icon: "⚠️", need: ["occurrences.create", "occurrences.manage"] },
  { href: "/importar", label: "Importar planilha", icon: "📥", need: ["import.run"] },
  { href: "/relatorios", label: "Relatórios", icon: "📊", need: ["reports.view"] },
  { href: "/auditoria", label: "Auditoria", icon: "🛡️", need: ["audit.view"] },
  { href: "/usuarios", label: "Funcionários", icon: "🔑", need: ["users.manage_portaria", "users.manage_all"] },
  { href: "/permissoes", label: "Permissões", icon: "⚙️", need: ["permissions.manage"] },
  { href: "/privacidade", label: "Privacidade (LGPD)", icon: "📄", need: [] },
];

export default function Shell({ me, children }: { me: Me; children: React.ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const items = ITEMS.filter((i) => i.need.length === 0 || i.need.some((n) => me.perms.includes(n)));
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/login"; }
  return (
    <Ctx.Provider value={me}>
      <div className="top"><b>🌿 Recanto dos Sabiás</b><button onClick={() => setOpen(!open)}>{open ? "Fechar" : "Menu"}</button></div>
      <div className="shell">
        <aside className={"side" + (open ? " open" : "")}>
          <div className="brand"><div className="logo">🌿</div><div>Recanto<br />dos Sabiás</div></div>
          {items.map((i) => (
            <Link key={i.href} href={i.href} onClick={() => setOpen(false)} className={"nav" + (path === i.href ? " on" : "")}>{i.icon} {i.label}</Link>
          ))}
          <div className="who">{me.name}<br />{ROLE[me.role]}<br /><button className="btn ghost sm" style={{ marginTop: 8 }} onClick={logout}>Sair</button></div>
        </aside>
        <main className="main">{children}</main>
      </div>
    </Ctx.Provider>
  );
}
